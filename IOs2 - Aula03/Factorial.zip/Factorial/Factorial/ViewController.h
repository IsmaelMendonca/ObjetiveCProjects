//
//  ViewController.h
//  Factorial
//
//  Created by ADMINISTRADOR on 28/09/16.
//  Copyright © 2016 ADMINISTRADOR. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

